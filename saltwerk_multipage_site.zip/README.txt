SALTWERK MULTI-PAGE WEBSITE

Upload all six HTML files and the required existing website assets to the same GitHub Pages root folder. Keep image filenames exactly as referenced. Required newly uploaded images: TrailGuard Calf Sleeve Green.png, TrailGuard Colors.png, TrailGuard Compression Sleeve Tech Board(1).png. Keep the existing assets referenced by the original site (logo, fonts, hero imagery, problem imagery, etc.) in the same root folder too. Set index.html as the homepage.

Pages: index.html, trailguard.html, explore.html, our-story.html, community.html, contact.html.

The Explore page embeds the BYU ArcGIS Atlas map. The Contact page uses mailto:daren@saltwerk.com. Google Analytics ID G-WW9S71MVS0 is retained in every page.
